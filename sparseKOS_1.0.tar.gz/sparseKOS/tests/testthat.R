library(testthat)
library(sparseKOS)

test_check("sparseKOS")
